# Discord Selfbot for skidding webhook embed
## Dev by npdk1
## Developer Github : https://github.com/npdk1
<img src="https://i.imgur.com/dy4uLbW.png" alt="WebhookShowcase">