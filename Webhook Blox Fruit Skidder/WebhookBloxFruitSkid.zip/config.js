module.exports = {
  noti_key: "npdk1ontop",
  name_server: "DYS | Community",
  invite_discord: "https://discord.gg/5w2jwtDe7E",
  token: "youraccounttoken",
  ownerID: "1311904823699963947",
  avtOwner: "https://i.imgur.com/I1qfyoF.jpeg", 
  nameOwner: "deptraicogihayhahah",
  random_anime_picture: true,
  notifications: {
      fullmoon: {
          enabled: true,
          channel_id: "",
          webhook: ""       
	    },
	    cursed_captain: {
          enabled: true,
          channel_id: "",
          webhook: ""       
	    },
  }
};